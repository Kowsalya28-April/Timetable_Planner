/**
 * ATRIA INSTITUTE OF TECHNOLOGY
 * Constraint Satisfaction Problem (CSP) & Backtracking Timetable Solver
 *
 * Implements:
 * - Variable Representation (Classes, Subjects, Labs with multi-period blocks)
 * - Domain Generation with Break Boundary Awareness
 * - Hard Constraints (No Faculty Overlap, No Room Overlap, No Section Clash, Lab Continuity, Max Consecutive Limits)
 * - Soft / Custom Constraints (Blocked Faculty Times, Blocked Class Slots, Lecture Spread)
 * - MRV (Minimum Remaining Values) & Degree Heuristics
 * - Forward Checking & Domain Pruning
 * - Comprehensive Conflict Diagnostics on Failure
 */

class CSPSolver {
  constructor(config = {}) {
    this.classes = config.classes || [];
    this.subjects = config.subjects || [];
    this.faculty = config.faculty || [];
    this.rooms = config.rooms || [];
    this.settings = config.settings || {};
    this.constraints = config.constraints || {};
    
    this.workingDays = this.settings.workingDays || ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    this.numDays = this.workingDays.length;
    this.periodsPerDay = this.settings.periodsPerDay || 7;
    this.breaks = this.settings.breaks || [];

    // Map breaks by afterPeriod for fast lookup
    this.breakAfterPeriods = new Set(this.breaks.map(b => b.afterPeriod));

    // Stats
    this.stats = {
      variablesCount: 0,
      assignmentsTried: 0,
      backtracksCount: 0,
      startTime: 0,
      endTime: 0,
      elapsedMs: 0,
      success: false
    };

    // Diagnostics / Bottlenecks
    this.conflicts = [];
  }

  /**
   * Main Entry Point
   */
  solve() {
    this.stats.startTime = performance.now();
    this.stats.assignmentsTried = 0;
    this.stats.backtracksCount = 0;
    this.conflicts = [];

    // 1. Build CSP Variables
    const variables = this.buildVariables();
    this.stats.variablesCount = variables.length;

    // Quick feasibility check
    const feasibility = this.checkBasicFeasibility(variables);
    if (!feasibility.possible) {
      this.stats.endTime = performance.now();
      this.stats.elapsedMs = Math.round(this.stats.endTime - this.stats.startTime);
      return {
        success: false,
        error: feasibility.reason,
        conflicts: this.conflicts,
        stats: this.stats
      };
    }

    // 2. Generate Initial Domains for each variable
    const domains = new Map();
    for (const v of variables) {
      const validSlots = this.generateInitialDomain(v);
      if (validSlots.length === 0) {
        this.conflicts.push(`Subject ${v.subjectCode} (${v.className}) has 0 valid time slots with current constraints.`);
        this.stats.endTime = performance.now();
        this.stats.elapsedMs = Math.round(this.stats.endTime - this.stats.startTime);
        return {
          success: false,
          error: `Zero valid slots available for ${v.subjectCode} (${v.subjectName}) in ${v.className}. Check blocked constraints.`,
          conflicts: this.conflicts,
          stats: this.stats
        };
      }
      domains.set(v.id, validSlots);
    }

    // 3. Grid structures for O(1) consistency checks
    // Key: [classId][day][period] -> variableId
    const classGrid = {};
    // Key: [facultyId][day][period] -> variableId
    const facultyGrid = {};
    // Key: [roomId][day][period] -> variableId
    const roomGrid = {};
    // Key: [facultyId][day] -> count of periods
    const facultyDailyCount = {};
    // Key: [classId][subjectId][day] -> count of lectures
    const classSubjectDailyCount = {};

    this.classes.forEach(c => {
      classGrid[c.id] = Array.from({ length: this.numDays }, () => Array(this.periodsPerDay + 1).fill(null));
      classSubjectDailyCount[c.id] = {};
    });

    this.faculty.forEach(f => {
      facultyGrid[f.id] = Array.from({ length: this.numDays }, () => Array(this.periodsPerDay + 1).fill(null));
      facultyDailyCount[f.id] = Array(this.numDays).fill(0);
    });

    this.rooms.forEach(r => {
      roomGrid[r.id] = Array.from({ length: this.numDays }, () => Array(this.periodsPerDay + 1).fill(null));
    });

    const assignment = new Map(); // variableId -> slot

    // 4. Run Backtracking Search with MRV & Forward Checking
    const MAX_BACKTRACKS = 25000;
    const success = this.backtrack(
      assignment,
      variables,
      domains,
      classGrid,
      facultyGrid,
      roomGrid,
      facultyDailyCount,
      classSubjectDailyCount,
      MAX_BACKTRACKS
    );

    this.stats.endTime = performance.now();
    this.stats.elapsedMs = Math.round(this.stats.endTime - this.stats.startTime);
    this.stats.success = success;

    if (!success) {
      if (this.conflicts.length === 0) {
        this.conflicts.push("Search space exhausted or maximum backtracking budget reached without satisfying all simultaneous constraints.");
        this.conflicts.push("Suggestion: Check if shared faculty (e.g. Dr. RKS or Prof. AP) have too many hours across sections or tight blocked periods.");
      }
      return {
        success: false,
        error: "Unable to find conflict-free timetable satisfying all constraints.",
        conflicts: this.conflicts,
        stats: this.stats
      };
    }

    // 5. Build Final Formatted Timetable
    const formattedResult = this.formatTimetable(assignment, variables);
    return {
      success: true,
      timetable: formattedResult.classTimetables,
      classTimetables: formattedResult.classTimetables,
      facultyTimetables: formattedResult.facultyTimetables,
      roomTimetables: formattedResult.roomTimetables,
      facultyWorkload: formattedResult.facultyWorkload,
      stats: this.stats
    };
  }

  /**
   * Convert subjects into discrete variables.
   * A 4-hour lecture becomes 4 individual 1-period variables.
   * A 2-hour lab becomes 1 atomic 2-period variable.
   */
  buildVariables() {
    const variables = [];

    this.classes.forEach(cls => {
      const classSubjects = this.subjects.filter(s => s.classId === cls.id);
      
      classSubjects.forEach(sub => {
        const fac = this.faculty.find(f => f.id === sub.facultyId);
        const room = this.rooms.find(r => r.id === sub.roomId);
        const duration = sub.type === "Lab" ? (sub.duration || 2) : 1;
        const totalHours = sub.hoursPerWeek || 3;
        const numEvents = sub.type === "Lab" ? Math.max(1, Math.floor(totalHours / duration)) : totalHours;

        for (let i = 1; i <= numEvents; i++) {
          variables.push({
            id: `${cls.id}_${sub.id}_ev${i}`,
            classId: cls.id,
            className: cls.name,
            subjectId: sub.id,
            subjectCode: sub.code,
            subjectName: sub.name,
            shortName: sub.shortName || sub.code,
            type: sub.type,
            duration: duration,
            eventIndex: i,
            totalEvents: numEvents,
            facultyId: sub.facultyId,
            facultyName: fac ? fac.name : "Unassigned",
            facultyInitials: fac ? fac.initials : "NA",
            roomId: sub.roomId || cls.defaultRoom,
            roomName: room ? room.name : (sub.roomId || cls.defaultRoom),
            credits: sub.credits || 3,
            batches: sub.batches || ""
          });
        }
      });
    });

    return variables;
  }

  /**
   * Pre-flight Capacity & Feasibility Check
   */
  checkBasicFeasibility(variables) {
    const totalSlotsPerClass = this.numDays * this.periodsPerDay;

    // Check each class's total required hours
    for (const cls of this.classes) {
      const clsVars = variables.filter(v => v.classId === cls.id);
      const totalReqHours = clsVars.reduce((sum, v) => sum + v.duration, 0);

      if (totalReqHours > totalSlotsPerClass) {
        const msg = `Class ${cls.name} requires ${totalReqHours} hours, but the week only has ${totalSlotsPerClass} available periods!`;
        this.conflicts.push(msg);
        return { possible: false, reason: msg };
      }
    }

    // Check each faculty member's total teaching load
    for (const fac of this.faculty) {
      const facVars = variables.filter(v => v.facultyId === fac.id);
      const totalFacHours = facVars.reduce((sum, v) => sum + v.duration, 0);

      if (fac.maxWeeklyHours && totalFacHours > fac.maxWeeklyHours) {
        const msg = `Faculty ${fac.name} (${fac.initials}) is assigned ${totalFacHours} hours/week, which exceeds their maximum weekly workload of ${fac.maxWeeklyHours} hours!`;
        this.conflicts.push(msg);
        return { possible: false, reason: msg };
      }
    }

    return { possible: true };
  }

  /**
   * Generate initial domain of valid (day, period) slots for a variable
   * taking into account break boundaries and fixed custom blocked slots.
   */
  generateInitialDomain(variable) {
    const domain = [];

    for (let day = 0; day < this.numDays; day++) {
      const dayName = this.workingDays[day];

      for (let period = 1; period <= this.periodsPerDay - variable.duration + 1; period++) {
        // 1. Break Boundary Constraint for Multi-Period Labs
        // Labs cannot cross a tea break or lunch break!
        let crossesBreak = false;
        if (variable.duration > 1) {
          for (let offset = 0; offset < variable.duration - 1; offset++) {
            const currentP = period + offset;
            if (this.breakAfterPeriods.has(currentP)) {
              crossesBreak = true;
              break;
            }
          }
        }
        if (crossesBreak) continue;

        // 2. Check Custom Soft/Blocked Conditions
        let isBlocked = false;
        if (this.constraints.customConditions && this.constraints.customConditions.length > 0) {
          for (const cond of this.constraints.customConditions) {
            if (!cond.active) continue;

            // Blocked faculty condition
            if (cond.type === "block_faculty" && cond.facultyId === variable.facultyId && cond.day === dayName) {
              if (cond.periods && cond.periods.some(p => p >= period && p < period + variable.duration)) {
                isBlocked = true;
                break;
              }
            }

            // Blocked class condition
            if (cond.type === "block_class" && cond.classId === variable.classId && cond.day === dayName) {
              if (cond.periods && cond.periods.some(p => p >= period && p < period + variable.duration)) {
                isBlocked = true;
                break;
              }
            }

            // No labs after specific period (e.g. Saturday afternoon)
            if (cond.type === "no_labs_after" && variable.type === "Lab" && cond.day === dayName) {
              if (period > cond.period) {
                isBlocked = true;
                break;
              }
            }
          }
        }

        if (isBlocked) continue;

        domain.push({ day, period, dayName });
      }
    }

    return domain;
  }

  /**
   * Consistency Check: Checks if assigning `variable` to `slot` violates any active constraint.
   */
  isConsistent(
    variable,
    slot,
    classGrid,
    facultyGrid,
    roomGrid,
    facultyDailyCount,
    classSubjectDailyCount
  ) {
    const { day, period } = slot;
    const duration = variable.duration;

    for (let offset = 0; offset < duration; offset++) {
      const p = period + offset;

      // Constraint 1: Class Overlap
      if (classGrid[variable.classId][day][p] !== null) {
        return false;
      }

      // Constraint 2: Faculty Overlap (Hard Constraint)
      if (this.constraints.facultyNoOverlap && variable.facultyId) {
        if (facultyGrid[variable.facultyId][day][p] !== null) {
          return false;
        }
      }

      // Constraint 3: Room Overlap (Hard Constraint)
      if (this.constraints.roomNoOverlap && variable.roomId) {
        if (roomGrid[variable.roomId][day][p] !== null) {
          return false;
        }
      }
    }

    // Constraint 4: Faculty Daily Workload Limit
    if (variable.facultyId && this.constraints.maxDailyFacultyHours) {
      const currentDaily = facultyDailyCount[variable.facultyId][day] || 0;
      if (currentDaily + duration > this.constraints.maxDailyFacultyHours) {
        return false;
      }
    }

    // Constraint 5: Max Consecutive Classes for Faculty
    if (variable.facultyId && this.constraints.maxConsecutiveClasses) {
      const maxConsec = this.constraints.maxConsecutiveClasses;
      let consecutiveBefore = 0;
      let checkP = period - 1;
      while (checkP >= 1 && facultyGrid[variable.facultyId][day][checkP] !== null && !this.breakAfterPeriods.has(checkP)) {
        consecutiveBefore++;
        checkP--;
      }

      let consecutiveAfter = 0;
      checkP = period + duration;
      while (checkP <= this.periodsPerDay && facultyGrid[variable.facultyId][day][checkP] !== null && !this.breakAfterPeriods.has(checkP - 1)) {
        consecutiveAfter++;
        checkP++;
      }

      if (consecutiveBefore + duration + consecutiveAfter > maxConsec) {
        return false;
      }
    }

    // Constraint 6: Lecture Spread Heuristic (Soft / Configurable)
    // Avoid having the same subject lecture more than once on the same day for a class
    if (this.constraints.spreadLectures && variable.type === "Lecture") {
      const daySubjectCount = (classSubjectDailyCount[variable.classId][variable.subjectId] &&
                               classSubjectDailyCount[variable.classId][variable.subjectId][day]) || 0;
      if (daySubjectCount >= 1) {
        // Only allow if necessary (e.g. if required hours > available days)
        const sub = this.subjects.find(s => s.id === variable.subjectId);
        if (sub && sub.hoursPerWeek <= this.numDays) {
          return false;
        }
      }
    }

    return true;
  }

  /**
   * MRV (Minimum Remaining Values) Variable Selection with Degree Heuristic Tie-Breaker
   */
  selectUnassignedVariable(unassignedVars, domains) {
    let bestVar = null;
    let minDomainSize = Infinity;
    let maxDegree = -1;

    for (const v of unassignedVars) {
      const domainSize = domains.get(v.id).length;
      // Degree: Labs have higher degree, shared faculty have higher degree
      const degree = (v.duration * 10) + (v.totalEvents || 1);

      if (domainSize < minDomainSize) {
        minDomainSize = domainSize;
        bestVar = v;
        maxDegree = degree;
      } else if (domainSize === minDomainSize) {
        if (degree > maxDegree) {
          maxDegree = degree;
          bestVar = v;
        }
      }
    }

    return bestVar;
  }

  /**
   * Value Ordering Heuristic: Sort legal slots to prefer balanced day distribution
   */
  orderDomainValues(variable, legalValues, classSubjectDailyCount) {
    return legalValues.slice().sort((a, b) => {
      // Prefer days with 0 lectures of this subject
      const countA = (classSubjectDailyCount[variable.classId][variable.subjectId] &&
                      classSubjectDailyCount[variable.classId][variable.subjectId][a.day]) || 0;
      const countB = (classSubjectDailyCount[variable.classId][variable.subjectId] &&
                      classSubjectDailyCount[variable.classId][variable.subjectId][b.day]) || 0;
      if (countA !== countB) return countA - countB;

      // Prefer morning / earlier slots for core theory lectures
      if (variable.type === "Lecture") {
        return a.period - b.period;
      }
      // Labs prefer standard blocks: P1-P2, P3-P4, P5-P6
      return a.period - b.period;
    });
  }

  /**
   * Forward Checking: Prune domains of unassigned variables and detect empty domains
   */
  forwardCheck(variable, slot, unassignedVars, domains, classGrid, facultyGrid, roomGrid, facultyDailyCount, classSubjectDailyCount) {
    const pruned = new Map(); // varId -> array of pruned slots

    for (const otherVar of unassignedVars) {
      // Only variables sharing class, faculty, or room can be affected
      const sharesClass = otherVar.classId === variable.classId;
      const sharesFaculty = otherVar.facultyId === variable.facultyId;
      const sharesRoom = otherVar.roomId === variable.roomId;

      if (!sharesClass && !sharesFaculty && !sharesRoom) {
        continue;
      }

      const currentDomain = domains.get(otherVar.id);
      const remainingDomain = [];
      const removedSlots = [];

      for (const otherSlot of currentDomain) {
        if (this.isConsistent(otherVar, otherSlot, classGrid, facultyGrid, roomGrid, facultyDailyCount, classSubjectDailyCount)) {
          remainingDomain.push(otherSlot);
        } else {
          removedSlots.push(otherSlot);
        }
      }

      if (removedSlots.length > 0) {
        pruned.set(otherVar.id, removedSlots);
        domains.set(otherVar.id, remainingDomain);
      }

      // If domain is wiped out, forward check fails immediately!
      if (remainingDomain.length === 0) {
        return { success: false, pruned };
      }
    }

    return { success: true, pruned };
  }

  /**
   * Restore pruned values during backtracking
   */
  restorePruned(domains, pruned) {
    for (const [varId, removedSlots] of pruned.entries()) {
      const current = domains.get(varId);
      domains.set(varId, current.concat(removedSlots));
    }
  }

  /**
   * Recursive Backtracking with Forward Checking
   */
  backtrack(
    assignment,
    variables,
    domains,
    classGrid,
    facultyGrid,
    roomGrid,
    facultyDailyCount,
    classSubjectDailyCount,
    maxBacktracks
  ) {
    if (assignment.size === variables.length) {
      return true; // All variables successfully assigned!
    }

    if (this.stats.backtracksCount >= maxBacktracks) {
      return false; // Budget limit reached
    }

    const unassignedVars = variables.filter(v => !assignment.has(v.id));
    const variable = this.selectUnassignedVariable(unassignedVars, domains);

    if (!variable) return false;

    const domainValues = domains.get(variable.id) || [];
    const orderedValues = this.orderDomainValues(variable, domainValues, classSubjectDailyCount);

    for (const slot of orderedValues) {
      this.stats.assignmentsTried++;

      if (this.isConsistent(variable, slot, classGrid, facultyGrid, roomGrid, facultyDailyCount, classSubjectDailyCount)) {
        // --- 1. Apply Assignment ---
        assignment.set(variable.id, slot);

        const { day, period } = slot;
        for (let off = 0; off < variable.duration; off++) {
          const p = period + off;
          classGrid[variable.classId][day][p] = variable.id;
          if (variable.facultyId) facultyGrid[variable.facultyId][day][p] = variable.id;
          if (variable.roomId) roomGrid[variable.roomId][day][p] = variable.id;
        }

        if (variable.facultyId) {
          facultyDailyCount[variable.facultyId][day] = (facultyDailyCount[variable.facultyId][day] || 0) + variable.duration;
        }

        if (!classSubjectDailyCount[variable.classId][variable.subjectId]) {
          classSubjectDailyCount[variable.classId][variable.subjectId] = {};
        }
        classSubjectDailyCount[variable.classId][variable.subjectId][day] =
          (classSubjectDailyCount[variable.classId][variable.subjectId][day] || 0) + 1;

        // --- 2. Forward Checking ---
        const remainingUnassigned = unassignedVars.filter(v => v.id !== variable.id);
        const fcResult = this.forwardCheck(
          variable,
          slot,
          remainingUnassigned,
          domains,
          classGrid,
          facultyGrid,
          roomGrid,
          facultyDailyCount,
          classSubjectDailyCount
        );

        if (fcResult.success) {
          // Recurse
          const result = this.backtrack(
            assignment,
            variables,
            domains,
            classGrid,
            facultyGrid,
            roomGrid,
            facultyDailyCount,
            classSubjectDailyCount,
            maxBacktracks
          );

          if (result) return true;
        }

        // --- 3. Undo Assignment (Backtrack) ---
        this.stats.backtracksCount++;
        this.restorePruned(domains, fcResult.pruned);

        for (let off = 0; off < variable.duration; off++) {
          const p = period + off;
          classGrid[variable.classId][day][p] = null;
          if (variable.facultyId) facultyGrid[variable.facultyId][day][p] = null;
          if (variable.roomId) roomGrid[variable.roomId][day][p] = null;
        }

        if (variable.facultyId) {
          facultyDailyCount[variable.facultyId][day] -= variable.duration;
        }
        classSubjectDailyCount[variable.classId][variable.subjectId][day] -= 1;

        assignment.delete(variable.id);
      }
    }

    return false;
  }

  /**
   * Format the final timetable into convenient view-ready data structures
   */
  formatTimetable(assignment, variables) {
    const classTimetables = {};
    const facultyTimetables = {};
    const roomTimetables = {};
    const facultyWorkload = {};

    // Initialize class tables
    this.classes.forEach(c => {
      classTimetables[c.id] = {
        classInfo: c,
        schedule: Array.from({ length: this.numDays }, () => Array(this.periodsPerDay + 1).fill(null)),
        legend: []
      };
    });

    // Initialize faculty tables
    this.faculty.forEach(f => {
      facultyTimetables[f.id] = {
        facultyInfo: f,
        schedule: Array.from({ length: this.numDays }, () => Array(this.periodsPerDay + 1).fill(null))
      };
      facultyWorkload[f.id] = {
        facultyInfo: f,
        totalHours: 0,
        subjects: new Set(),
        classes: new Set(),
        dailyHours: Array(this.numDays).fill(0)
      };
    });

    // Initialize room tables
    this.rooms.forEach(r => {
      roomTimetables[r.id] = {
        roomInfo: r,
        schedule: Array.from({ length: this.numDays }, () => Array(this.periodsPerDay + 1).fill(null))
      };
    });

    // Populate allocations
    for (const [varId, slot] of assignment.entries()) {
      const v = variables.find(x => x.id === varId);
      if (!v) continue;

      const { day, period } = slot;
      const duration = v.duration;

      // Fill in Class schedule
      for (let off = 0; off < duration; off++) {
        const p = period + off;
        const entry = {
          variableId: v.id,
          classId: v.classId,
          className: v.className,
          subjectId: v.subjectId,
          subjectCode: v.subjectCode,
          subjectName: v.subjectName,
          shortName: v.shortName,
          type: v.type,
          duration: duration,
          isSpanStart: (off === 0),
          spanOffset: off,
          facultyId: v.facultyId,
          facultyName: v.facultyName,
          facultyInitials: v.facultyInitials,
          roomId: v.roomId,
          roomName: v.roomName,
          batches: v.batches || ""
        };

        classTimetables[v.classId].schedule[day][p] = entry;

        if (v.facultyId && facultyTimetables[v.facultyId]) {
          facultyTimetables[v.facultyId].schedule[day][p] = entry;
        }

        if (v.roomId && roomTimetables[v.roomId]) {
          roomTimetables[v.roomId].schedule[day][p] = entry;
        }
      }

      // Update Faculty Workload summary
      if (v.facultyId && facultyWorkload[v.facultyId]) {
        facultyWorkload[v.facultyId].totalHours += duration;
        facultyWorkload[v.facultyId].subjects.add(v.subjectCode);
        facultyWorkload[v.facultyId].classes.add(v.classId);
        facultyWorkload[v.facultyId].dailyHours[day] += duration;
      }
    }

    // Build Legend for each class
    this.classes.forEach(c => {
      const classSubjects = this.subjects.filter(s => s.classId === c.id);
      classTimetables[c.id].legend = classSubjects.map((sub, idx) => {
        const fac = this.faculty.find(f => f.id === sub.facultyId);
        const room = this.rooms.find(r => r.id === sub.roomId);
        return {
          slNo: idx + 1,
          code: sub.code,
          name: sub.name,
          shortName: sub.shortName || sub.code,
          type: sub.type,
          hoursPerWeek: sub.hoursPerWeek,
          facultyName: fac ? fac.name : "Unassigned",
          facultyInitials: fac ? fac.initials : "NA",
          roomName: room ? room.name : (sub.roomId || c.defaultRoom),
          batches: sub.batches || (sub.type === "Lab" ? "B1, B2" : "-")
        };
      });
    });

    // Convert Sets to Arrays in facultyWorkload
    Object.values(facultyWorkload).forEach(fw => {
      fw.subjects = Array.from(fw.subjects);
      fw.classes = Array.from(fw.classes);
    });

    return {
      classTimetables,
      facultyTimetables,
      roomTimetables,
      facultyWorkload
    };
  }
}
