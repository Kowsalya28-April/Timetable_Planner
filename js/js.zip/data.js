/**
 * ATRIA INSTITUTE OF TECHNOLOGY - Timetable Planner
 * Initial Seed Data & LocalStorage State Management
 */

const STORAGE_KEYS = {
  CLASSES: 'atria_classes',
  SUBJECTS: 'atria_subjects',
  FACULTY: 'atria_faculty',
  ROOMS: 'atria_rooms',
  CONSTRAINTS: 'atria_constraints',
  SETTINGS: 'atria_settings',
  METADATA: 'atria_metadata',
  USERS: 'atria_users',
  TIMETABLE: 'atria_generated_timetable',
  CUSTOM_LOGO: 'atria_custom_logo',
  ACTIVE_USER: 'atria_active_user'
};

const DEFAULT_METADATA = {
  instituteName: "ATRIA INSTITUTE OF TECHNOLOGY",
  instituteAffiliation: "An Autonomous Institution Affiliated to VTU, Belagavi | Approved by AICTE, New Delhi",
  instituteAddress: "Anandnagar, Bengaluru - 560 024, Karnataka, India",
  department: "DEPARTMENT OF ARTIFICIAL INTELLIGENCE & COMPUTER SCIENCE",
  academicYear: "2024 - 2025",
  semesterType: "Odd Semester",
  wefDate: "01-08-2024",
  revision: "Rev 2.2",
  coordinatorSignLabel: "Timetable Coordinator",
  coordinatorName: "Prof. H. R. Naveen",
  hodSignLabel: "Head of Department (HOD)",
  hodName: "Dr. R. K. Sharma",
  principalSignLabel: "Principal / Dean Academic",
  principalName: "Dr. T. N. Sreenivasa"
};

const DEFAULT_SETTINGS = {
  workingDays: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
  periodsPerDay: 7,
  periodTimes: [
    { period: 1, start: "09:00", end: "09:55", label: "Period 1 (09:00 - 09:55)" },
    { period: 2, start: "09:55", end: "10:50", label: "Period 2 (09:55 - 10:50)" },
    // Tea Break occurs after Period 2 (10:50 - 11:05)
    { period: 3, start: "11:05", end: "12:00", label: "Period 3 (11:05 - 12:00)" },
    { period: 4, start: "12:00", end: "12:55", label: "Period 4 (12:00 - 12:55)" },
    // Lunch Break occurs after Period 4 (12:55 - 01:45)
    { period: 5, start: "01:45", end: "02:40", label: "Period 5 (01:45 - 02:40)" },
    { period: 6, start: "02:40", end: "03:35", label: "Period 6 (02:40 - 03:35)" },
    { period: 7, start: "03:35", end: "04:30", label: "Period 7 (03:35 - 04:30)" }
  ],
  breaks: [
    { id: "tea", name: "TEA BREAK", afterPeriod: 2, start: "10:50", end: "11:05", duration: "15 Min" },
    { id: "lunch", name: "LUNCH BREAK", afterPeriod: 4, start: "12:55", end: "01:45", duration: "50 Min" }
  ]
};

const DEFAULT_CONSTRAINTS = {
  facultyNoOverlap: true,      // Zero faculty overlap
  roomNoOverlap: true,         // Zero room overlap
  consecutiveLabs: true,       // Labs scheduled continuously (2 periods)
  maxConsecutiveClasses: 3,    // Max consecutive classes for faculty
  maxDailyFacultyHours: 4,     // Max hours per faculty per day
  spreadLectures: true,        // Spread lectures across days
  
  customConditions: [
    {
      id: "cond-1",
      name: "Dr. RKS Administrative Duties",
      type: "block_faculty",
      facultyId: "FAC-01",
      day: "Monday",
      periods: [1, 2],
      active: true,
      description: "Dr. R.K. Sharma is unavailable on Monday Period 1 & 2 for HoD Admin Council"
    },
    {
      id: "cond-2",
      name: "CSE-5A Technical Forum / Seminar",
      type: "block_class",
      classId: "CSE-5A",
      day: "Friday",
      periods: [7],
      active: true,
      description: "CSE-5A reserved for Department Technical Forum / Seminar on Friday Period 7"
    },
    {
      id: "cond-3",
      name: "Prof. VM Research Slot",
      type: "block_faculty",
      facultyId: "FAC-03",
      day: "Wednesday",
      periods: [6, 7],
      active: true,
      description: "Prof. Vikram Mehra reserved for Research & Lab Maintenance on Wednesday P6-P7"
    },
    {
      id: "cond-4",
      name: "Saturday Half-Day / No Labs after Period 4",
      type: "no_labs_after",
      day: "Saturday",
      period: 4,
      active: true,
      description: "No continuous lab sessions scheduled on Saturday afternoon"
    }
  ]
};

const DEFAULT_CLASSES = [
  {
    id: "AIML-3A",
    name: "3rd Sem - Section A (AIML)",
    department: "Artificial Intelligence & Machine Learning",
    semester: 3,
    section: "A",
    defaultRoom: "AI-LAB",
    studentCount: 60,
    academicYear: "2024 - 2025"
  },
  {
    id: "CSE-5A",
    name: "5th Sem - Section A (CSE)",
    department: "Computer Science & Engineering",
    semester: 5,
    section: "A",
    defaultRoom: "LH-204",
    studentCount: 65,
    academicYear: "2024 - 2025"
  },
  {
    id: "CSE-5B",
    name: "5th Sem - Section B (CSE)",
    department: "Computer Science & Engineering",
    semester: 5,
    section: "B",
    defaultRoom: "LH-205",
    studentCount: 62,
    academicYear: "2024 - 2025"
  },
  {
    id: "CSE-3A",
    name: "3rd Sem - Section A (CSE)",
    department: "Computer Science & Engineering",
    semester: 3,
    section: "A",
    defaultRoom: "LH-201",
    studentCount: 60,
    academicYear: "2024 - 2025"
  },
  {
    id: "ISE-5A",
    name: "5th Sem - Section A (ISE)",
    department: "Information Science & Engineering",
    semester: 5,
    section: "A",
    defaultRoom: "LH-302",
    studentCount: 58,
    academicYear: "2024 - 2025"
  }
];

const DEFAULT_FACULTY = [
  {
    id: "FAC-01",
    name: "Dr. R. K. Sharma",
    initials: "RKS",
    designation: "Professor & HOD",
    department: "CSE",
    email: "rk.sharma@atria.edu",
    maxDailyHours: 4,
    maxWeeklyHours: 18,
    color: "#831843"
  },
  {
    id: "FAC-02",
    name: "Prof. Ananya Patel",
    initials: "AP",
    designation: "Associate Professor",
    department: "CSE",
    email: "ananya.p@atria.edu",
    maxDailyHours: 4,
    maxWeeklyHours: 16,
    color: "#0369a1"
  },
  {
    id: "FAC-03",
    name: "Prof. Vikram Mehra",
    initials: "VM",
    designation: "Assistant Professor",
    department: "CSE",
    email: "vikram.m@atria.edu",
    maxDailyHours: 4,
    maxWeeklyHours: 16,
    color: "#047857"
  },
  {
    id: "FAC-04",
    name: "Dr. Sunita Rao",
    initials: "SR",
    designation: "Associate Professor",
    department: "Mathematics",
    email: "sunita.r@atria.edu",
    maxDailyHours: 4,
    maxWeeklyHours: 18,
    color: "#b45309"
  },
  {
    id: "FAC-05",
    name: "Prof. Karthik N",
    initials: "KN",
    designation: "Assistant Professor",
    department: "CSE",
    email: "karthik.n@atria.edu",
    maxDailyHours: 4,
    maxWeeklyHours: 18,
    color: "#6d28d9"
  },
  {
    id: "FAC-06",
    name: "Prof. Deepa Nayak",
    initials: "DN",
    designation: "Assistant Professor",
    department: "ISE",
    email: "deepa.n@atria.edu",
    maxDailyHours: 4,
    maxWeeklyHours: 16,
    color: "#be185d"
  },
  {
    id: "FAC-07",
    name: "Prof. Rajesh G",
    initials: "RG",
    designation: "Assistant Professor",
    department: "AIML",
    email: "rajesh.g@atria.edu",
    maxDailyHours: 4,
    maxWeeklyHours: 18,
    color: "#c2410c"
  },
  {
    id: "FAC-08",
    name: "Dr. Pooja Suresh",
    initials: "PS",
    designation: "Associate Professor",
    department: "AIML",
    email: "pooja.s@atria.edu",
    maxDailyHours: 4,
    maxWeeklyHours: 16,
    color: "#0d9488"
  }
];

const DEFAULT_ROOMS = [
  { id: "LH-201", name: "Lecture Hall 201", capacity: 70, type: "Lecture", block: "Main Academic Block" },
  { id: "LH-204", name: "Lecture Hall 204", capacity: 70, type: "Lecture", block: "CS Block 2nd Floor" },
  { id: "LH-205", name: "Lecture Hall 205", capacity: 70, type: "Lecture", block: "CS Block 2nd Floor" },
  { id: "LH-302", name: "Lecture Hall 302", capacity: 70, type: "Lecture", block: "IS Block 3rd Floor" },
  { id: "CS-LAB-1", name: "Database & Web Lab", capacity: 36, type: "Lab", block: "CS Block Ground Floor" },
  { id: "CS-LAB-2", name: "Computer Networks Lab", capacity: 36, type: "Lab", block: "CS Block 1st Floor" },
  { id: "AI-LAB", name: "AI & Data Science Lab", capacity: 40, type: "Lab", block: "Tech Block 2nd Floor" }
];

const DEFAULT_SUBJECTS = [
  // --- Subjects for AIML-3A (Kowsalya G - 1AT24AI048) ---
  {
    id: "SUB-AI3-1",
    classId: "AIML-3A",
    code: "21MAT31",
    name: "Mathematical Foundations for AI",
    shortName: "Maths-AI",
    type: "Lecture",
    hoursPerWeek: 4,
    facultyId: "FAC-04",
    roomId: "AI-LAB",
    credits: 3
  },
  {
    id: "SUB-AI3-2",
    classId: "AIML-3A",
    code: "21AI32",
    name: "Data Structures with Python",
    shortName: "DS-Python",
    type: "Lecture",
    hoursPerWeek: 4,
    facultyId: "FAC-07",
    roomId: "AI-LAB",
    credits: 4
  },
  {
    id: "SUB-AI3-3",
    classId: "AIML-3A",
    code: "21AI33",
    name: "Principles of Artificial Intelligence",
    shortName: "AI-Fund",
    type: "Lecture",
    hoursPerWeek: 4,
    facultyId: "FAC-08",
    roomId: "AI-LAB",
    credits: 4
  },
  {
    id: "SUB-AI3-4",
    classId: "AIML-3A",
    code: "21AI34",
    name: "Object Oriented Programming (Java)",
    shortName: "OOP-Java",
    type: "Lecture",
    hoursPerWeek: 3,
    facultyId: "FAC-05",
    roomId: "AI-LAB",
    credits: 3
  },
  {
    id: "SUB-AI3-5",
    classId: "AIML-3A",
    code: "21AIL35",
    name: "AI & Python Laboratory",
    shortName: "AI Lab",
    type: "Lab",
    duration: 2,
    hoursPerWeek: 2,
    facultyId: "FAC-07",
    roomId: "AI-LAB",
    credits: 1.5,
    batches: "B1, B2"
  },
  {
    id: "SUB-AI3-6",
    classId: "AIML-3A",
    code: "21AIL36",
    name: "Data Structures & Java Lab",
    shortName: "DS Lab",
    type: "Lab",
    duration: 2,
    hoursPerWeek: 2,
    facultyId: "FAC-08",
    roomId: "CS-LAB-1",
    credits: 1.5,
    batches: "B1, B2"
  },
  {
    id: "SUB-AI3-7",
    classId: "AIML-3A",
    code: "21CIP37",
    name: "Constitution of India & Ethics",
    shortName: "CIP",
    type: "Lecture",
    hoursPerWeek: 2,
    facultyId: "FAC-04",
    roomId: "AI-LAB",
    credits: 1
  },

  // --- Subjects for CSE-5A ---
  {
    id: "SUB-5A-1",
    classId: "CSE-5A",
    code: "21CS51",
    name: "Automata Theory & Computability (ATC)",
    shortName: "ATC",
    type: "Lecture",
    hoursPerWeek: 4,
    facultyId: "FAC-01",
    roomId: "LH-204",
    credits: 3
  },
  {
    id: "SUB-5A-2",
    classId: "CSE-5A",
    code: "21CS52",
    name: "Computer Networks (CN)",
    shortName: "CN",
    type: "Lecture",
    hoursPerWeek: 4,
    facultyId: "FAC-02",
    roomId: "LH-204",
    credits: 4
  },
  {
    id: "SUB-5A-3",
    classId: "CSE-5A",
    code: "21CS53",
    name: "Database Management Systems (DBMS)",
    shortName: "DBMS",
    type: "Lecture",
    hoursPerWeek: 4,
    facultyId: "FAC-03",
    roomId: "LH-204",
    credits: 4
  },
  {
    id: "SUB-5A-4",
    classId: "CSE-5A",
    code: "21CS54",
    name: "Artificial Intelligence & Machine Learning",
    shortName: "AIML",
    type: "Lecture",
    hoursPerWeek: 3,
    facultyId: "FAC-07",
    roomId: "LH-204",
    credits: 3
  },
  {
    id: "SUB-5A-5",
    classId: "CSE-5A",
    code: "21CSL55",
    name: "DBMS Laboratory",
    shortName: "DBMS Lab",
    type: "Lab",
    duration: 2,
    hoursPerWeek: 2,
    facultyId: "FAC-03",
    roomId: "CS-LAB-1",
    credits: 1.5,
    batches: "B1, B2"
  },
  {
    id: "SUB-5A-6",
    classId: "CSE-5A",
    code: "21CSL56",
    name: "Computer Networks Laboratory",
    shortName: "CN Lab",
    type: "Lab",
    duration: 2,
    hoursPerWeek: 2,
    facultyId: "FAC-02",
    roomId: "CS-LAB-2",
    credits: 1.5,
    batches: "B1, B2"
  },
  {
    id: "SUB-5A-7",
    classId: "CSE-5A",
    code: "21CIV57",
    name: "Environmental Studies & Ethics",
    shortName: "EVS",
    type: "Lecture",
    hoursPerWeek: 2,
    facultyId: "FAC-04",
    roomId: "LH-204",
    credits: 1
  },

  // --- Subjects for CSE-5B ---
  {
    id: "SUB-5B-1",
    classId: "CSE-5B",
    code: "21CS51",
    name: "Automata Theory & Computability (ATC)",
    shortName: "ATC",
    type: "Lecture",
    hoursPerWeek: 4,
    facultyId: "FAC-01",
    roomId: "LH-205",
    credits: 3
  },
  {
    id: "SUB-5B-2",
    classId: "CSE-5B",
    code: "21CS52",
    name: "Computer Networks (CN)",
    shortName: "CN",
    type: "Lecture",
    hoursPerWeek: 4,
    facultyId: "FAC-05",
    roomId: "LH-205",
    credits: 4
  },
  {
    id: "SUB-5B-3",
    classId: "CSE-5B",
    code: "21CS53",
    name: "Database Management Systems (DBMS)",
    shortName: "DBMS",
    type: "Lecture",
    hoursPerWeek: 4,
    facultyId: "FAC-03",
    roomId: "LH-205",
    credits: 4
  },
  {
    id: "SUB-5B-4",
    classId: "CSE-5B",
    code: "21CS54",
    name: "Artificial Intelligence & Machine Learning",
    shortName: "AIML",
    type: "Lecture",
    hoursPerWeek: 3,
    facultyId: "FAC-07",
    roomId: "LH-205",
    credits: 3
  },
  {
    id: "SUB-5B-5",
    classId: "CSE-5B",
    code: "21CSL55",
    name: "DBMS Laboratory",
    shortName: "DBMS Lab",
    type: "Lab",
    duration: 2,
    hoursPerWeek: 2,
    facultyId: "FAC-03",
    roomId: "CS-LAB-1",
    credits: 1.5,
    batches: "B1, B2"
  },
  {
    id: "SUB-5B-6",
    classId: "CSE-5B",
    code: "21CSL56",
    name: "Computer Networks Laboratory",
    shortName: "CN Lab",
    type: "Lab",
    duration: 2,
    hoursPerWeek: 2,
    facultyId: "FAC-05",
    roomId: "CS-LAB-2",
    credits: 1.5,
    batches: "B1, B2"
  },
  {
    id: "SUB-5B-7",
    classId: "CSE-5B",
    code: "21CIV57",
    name: "Environmental Studies & Ethics",
    shortName: "EVS",
    type: "Lecture",
    hoursPerWeek: 2,
    facultyId: "FAC-04",
    roomId: "LH-205",
    credits: 1
  },

  // --- Subjects for CSE-3A ---
  {
    id: "SUB-3A-1",
    classId: "CSE-3A",
    code: "21MAT31",
    name: "Transform Calculus & Fourier Series",
    shortName: "Maths-III",
    type: "Lecture",
    hoursPerWeek: 4,
    facultyId: "FAC-04",
    roomId: "LH-201",
    credits: 3
  },
  {
    id: "SUB-3A-2",
    classId: "CSE-3A",
    code: "21CS32",
    name: "Data Structures and Applications",
    shortName: "DSA",
    type: "Lecture",
    hoursPerWeek: 4,
    facultyId: "FAC-05",
    roomId: "LH-201",
    credits: 4
  },
  {
    id: "SUB-3A-3",
    classId: "CSE-3A",
    code: "21CS33",
    name: "Analog and Digital Electronics",
    shortName: "ADE",
    type: "Lecture",
    hoursPerWeek: 4,
    facultyId: "FAC-02",
    roomId: "LH-201",
    credits: 4
  },
  {
    id: "SUB-3A-4",
    classId: "CSE-3A",
    code: "21CS34",
    name: "Computer Organization & Architecture",
    shortName: "COA",
    type: "Lecture",
    hoursPerWeek: 3,
    facultyId: "FAC-01",
    roomId: "LH-201",
    credits: 3
  },
  {
    id: "SUB-3A-5",
    classId: "CSE-3A",
    code: "21CSL35",
    name: "Data Structures Laboratory",
    shortName: "DSA Lab",
    type: "Lab",
    duration: 2,
    hoursPerWeek: 2,
    facultyId: "FAC-05",
    roomId: "CS-LAB-1",
    credits: 1.5,
    batches: "B1, B2"
  },
  {
    id: "SUB-3A-6",
    classId: "CSE-3A",
    code: "21CSL36",
    name: "ADE Laboratory",
    shortName: "ADE Lab",
    type: "Lab",
    duration: 2,
    hoursPerWeek: 2,
    facultyId: "FAC-02",
    roomId: "CS-LAB-2",
    credits: 1.5,
    batches: "B1, B2"
  },

  // --- Subjects for ISE-5A ---
  {
    id: "SUB-IS-1",
    classId: "ISE-5A",
    code: "21IS51",
    name: "Automata & Compiler Design",
    shortName: "ACD",
    type: "Lecture",
    hoursPerWeek: 4,
    facultyId: "FAC-06",
    roomId: "LH-302",
    credits: 3
  },
  {
    id: "SUB-IS-2",
    classId: "ISE-5A",
    code: "21IS52",
    name: "Software Engineering & Project Mgmt",
    shortName: "SEPM",
    type: "Lecture",
    hoursPerWeek: 4,
    facultyId: "FAC-06",
    roomId: "LH-302",
    credits: 4
  },
  {
    id: "SUB-IS-3",
    classId: "ISE-5A",
    code: "21IS53",
    name: "Database Management Systems",
    shortName: "DBMS",
    type: "Lecture",
    hoursPerWeek: 4,
    facultyId: "FAC-03",
    roomId: "LH-302",
    credits: 4
  },
  {
    id: "SUB-IS-4",
    classId: "ISE-5A",
    code: "21ISL55",
    name: "Database & Software Design Lab",
    shortName: "DBMS Lab",
    type: "Lab",
    duration: 2,
    hoursPerWeek: 2,
    facultyId: "FAC-06",
    roomId: "AI-LAB",
    credits: 1.5,
    batches: "B1, B2"
  }
];

const DEFAULT_USERS = [
  // Student Kowsalya G (1AT24AI048)
  {
    id: "USER-S-KOWSALYA",
    username: "1AT24AI048",
    password: "student123",
    name: "Kowsalya G",
    role: "student",
    classId: "AIML-3A",
    department: "Artificial Intelligence & Machine Learning",
    semester: 3,
    section: "A"
  },
  // Other Student Accounts
  {
    id: "USER-S1",
    username: "1AT21CS042",
    password: "student123",
    name: "Kavya Shree M",
    role: "student",
    classId: "CSE-5A",
    department: "Computer Science & Engineering",
    semester: 5,
    section: "A"
  },
  {
    id: "USER-S2",
    username: "1AT21CS088",
    password: "student123",
    name: "Rahul Verma",
    role: "student",
    classId: "CSE-5B",
    department: "Computer Science & Engineering",
    semester: 5,
    section: "B"
  },
  {
    id: "USER-S3",
    username: "1AT22CS015",
    password: "student123",
    name: "Sneha Kulkarni",
    role: "student",
    classId: "CSE-3A",
    department: "Computer Science & Engineering",
    semester: 3,
    section: "A"
  },
  {
    id: "USER-S4",
    username: "1AT21IS010",
    password: "student123",
    name: "Aditya Bhat",
    role: "student",
    classId: "ISE-5A",
    department: "Information Science & Engineering",
    semester: 5,
    section: "A"
  },

  // Staff (Staff User ID / Password)
  {
    id: "USER-F1",
    username: "ATRIA_FAC_101",
    password: "staff123",
    name: "Dr. R. K. Sharma",
    role: "staff",
    facultyId: "FAC-01",
    department: "Computer Science & Engineering",
    designation: "Professor & HOD"
  },
  {
    id: "USER-F2",
    username: "ATRIA_FAC_102",
    password: "staff123",
    name: "Prof. Ananya Patel",
    role: "staff",
    facultyId: "FAC-02",
    department: "Computer Science & Engineering",
    designation: "Associate Professor"
  },
  {
    id: "USER-F3",
    username: "ATRIA_FAC_103",
    password: "staff123",
    name: "Prof. Vikram Mehra",
    role: "staff",
    facultyId: "FAC-03",
    department: "Computer Science & Engineering",
    designation: "Assistant Professor"
  },

  // Admin (Admin ID / Password)
  {
    id: "USER-A1",
    username: "ADMIN01",
    password: "admin123",
    name: "Dr. T. N. Sreenivasa",
    role: "admin",
    department: "Dean Academics & Timetable Office",
    designation: "Academic Dean / Chief Administrator"
  }
];

/**
 * Storage Layer with Auto-Fallback & Version-Safe Schema Migration
 */
const AppStore = {
  get(key, defaultValue) {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : defaultValue;
    } catch (e) {
      console.warn(`LocalStorage read error for ${key}:`, e);
      return defaultValue;
    }
  },

  set(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error(`LocalStorage write error for ${key}:`, e);
    }
  },

  init() {
    if (!localStorage.getItem(STORAGE_KEYS.METADATA)) {
      this.set(STORAGE_KEYS.METADATA, DEFAULT_METADATA);
    }
    if (!localStorage.getItem(STORAGE_KEYS.SETTINGS)) {
      this.set(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.CONSTRAINTS)) {
      this.set(STORAGE_KEYS.CONSTRAINTS, DEFAULT_CONSTRAINTS);
    }

    // Dynamic Synchronization for Classes (guarantees AIML-3A is present)
    let storedClasses = this.get(STORAGE_KEYS.CLASSES, []);
    if (!storedClasses || storedClasses.length === 0) {
      this.set(STORAGE_KEYS.CLASSES, DEFAULT_CLASSES);
    } else {
      DEFAULT_CLASSES.forEach(dc => {
        if (!storedClasses.some(c => c.id === dc.id)) {
          storedClasses.unshift(dc); // Put AIML first
        }
      });
      this.set(STORAGE_KEYS.CLASSES, storedClasses);
    }

    // Dynamic Synchronization for Faculty
    let storedFaculty = this.get(STORAGE_KEYS.FACULTY, []);
    if (!storedFaculty || storedFaculty.length === 0) {
      this.set(STORAGE_KEYS.FACULTY, DEFAULT_FACULTY);
    } else {
      DEFAULT_FACULTY.forEach(df => {
        if (!storedFaculty.some(f => f.id === df.id)) {
          storedFaculty.push(df);
        }
      });
      this.set(STORAGE_KEYS.FACULTY, storedFaculty);
    }

    // Dynamic Synchronization for Rooms
    let storedRooms = this.get(STORAGE_KEYS.ROOMS, []);
    if (!storedRooms || storedRooms.length === 0) {
      this.set(STORAGE_KEYS.ROOMS, DEFAULT_ROOMS);
    } else {
      DEFAULT_ROOMS.forEach(dr => {
        if (!storedRooms.some(r => r.id === dr.id)) {
          storedRooms.push(dr);
        }
      });
      this.set(STORAGE_KEYS.ROOMS, storedRooms);
    }

    // Dynamic Synchronization for Subjects
    let storedSubjects = this.get(STORAGE_KEYS.SUBJECTS, []);
    if (!storedSubjects || storedSubjects.length === 0) {
      this.set(STORAGE_KEYS.SUBJECTS, DEFAULT_SUBJECTS);
    } else {
      DEFAULT_SUBJECTS.forEach(ds => {
        if (!storedSubjects.some(s => s.id === ds.id)) {
          storedSubjects.push(ds);
        }
      });
      this.set(STORAGE_KEYS.SUBJECTS, storedSubjects);
    }

    // Dynamic Synchronization for Users (guarantees 1AT24AI048 is present)
    let storedUsers = this.get(STORAGE_KEYS.USERS, []);
    if (!storedUsers || storedUsers.length === 0) {
      this.set(STORAGE_KEYS.USERS, DEFAULT_USERS);
    } else {
      DEFAULT_USERS.forEach(du => {
        const existingIdx = storedUsers.findIndex(u => u.username.toUpperCase() === du.username.toUpperCase());
        if (existingIdx === -1) {
          storedUsers.unshift(du);
        } else {
          storedUsers[existingIdx] = { ...storedUsers[existingIdx], ...du };
        }
      });
      this.set(STORAGE_KEYS.USERS, storedUsers);
    }

    // Set default logo from logoData if present and none stored
    if (!localStorage.getItem(STORAGE_KEYS.CUSTOM_LOGO) && typeof ATRIA_LOGO_BASE64 !== 'undefined') {
      this.set(STORAGE_KEYS.CUSTOM_LOGO, ATRIA_LOGO_BASE64);
    }
  },

  resetToDefaults() {
    this.set(STORAGE_KEYS.METADATA, DEFAULT_METADATA);
    this.set(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS);
    this.set(STORAGE_KEYS.CONSTRAINTS, DEFAULT_CONSTRAINTS);
    this.set(STORAGE_KEYS.CLASSES, DEFAULT_CLASSES);
    this.set(STORAGE_KEYS.FACULTY, DEFAULT_FACULTY);
    this.set(STORAGE_KEYS.ROOMS, DEFAULT_ROOMS);
    this.set(STORAGE_KEYS.SUBJECTS, DEFAULT_SUBJECTS);
    this.set(STORAGE_KEYS.USERS, DEFAULT_USERS);
    if (typeof ATRIA_LOGO_BASE64 !== 'undefined') {
      this.set(STORAGE_KEYS.CUSTOM_LOGO, ATRIA_LOGO_BASE64);
    }
    localStorage.removeItem(STORAGE_KEYS.TIMETABLE);
  }
};

// Initialize store on script load
AppStore.init();
